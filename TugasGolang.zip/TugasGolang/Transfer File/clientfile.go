package main

import (
	"fmt"
	"io"
	"net"
	"os"
	"path/filepath"
	"strings"

	"github.com/sqweek/dialog"
)

const (
	serverAddr = "localhost:9000"
	bufferSize = 1024
)

func main() {
	addr, err := net.ResolveUDPAddr("udp", serverAddr)
	if err != nil {
		fmt.Println("Error resolving address:", err)
		return
	}

	conn, err := net.DialUDP("udp", nil, addr)
	if err != nil {
		fmt.Println("Error connecting to server:", err)
		return
	}
	defer conn.Close()

	fmt.Println("Connected to server", serverAddr)

	for {
		fmt.Println("Enter command (UPLOAD, DOWNLOAD, LIST, EXIT):")
		var command string
		fmt.Scanln(&command)

		switch strings.ToUpper(command) {
		case "UPLOAD":
			handleUpload(conn)
		case "DOWNLOAD":
			fmt.Println("Enter file name to download:")
			var fileName string
			fmt.Scanln(&fileName)
			handleDownload(conn, fileName)
		case "LIST":
			handleList(conn)
		case "EXIT":
			fmt.Println("Exiting...")
			return
		default:
			fmt.Println("Invalid command")
		}
	}
}

func handleUpload(conn *net.UDPConn) {
	// Open file picker dialog
	filePath, err := dialog.File().Title("Select file to upload").Load()
	if err != nil {
		fmt.Println("Error selecting file:", err)
		return
	}

	file, err := os.Open(filePath)
	if err != nil {
		fmt.Println("Error opening file:", err)
		return
	}
	defer file.Close()

	// Extract only the file name from the full file path
	fileName := filepath.Base(filePath)

	// Send upload command with the file name
	_, err = conn.Write([]byte("UPLOAD " + fileName))
	if err != nil {
		fmt.Println("Error sending upload request:", err)
		return
	}

	buffer := make([]byte, bufferSize)
	n, _, err := conn.ReadFromUDP(buffer)
	if err != nil || string(buffer[:n]) != "READY" {
		fmt.Println("Error or server not ready:", err)
		return
	}

	// Send the file data to the server
	for {
		n, err := file.Read(buffer)
		if err != nil && err != io.EOF {
			fmt.Println("Error reading from file:", err)
			return
		}
		if n == 0 {
			break
		}

		conn.Write(buffer[:n])
	}

	conn.Write([]byte("EOF"))
	n, _, err = conn.ReadFromUDP(buffer)
	if err != nil || string(buffer[:n]) != "UPLOAD COMPLETE" {
		fmt.Println("Error or upload not complete:", err)
		return
	}

	fmt.Println("File uploaded:", fileName)
}

func handleDownload(conn *net.UDPConn, fileName string) {
	_, err := conn.Write([]byte("DOWNLOAD " + fileName))
	if err != nil {
		fmt.Println("Error sending download request:", err)
		return
	}

	buffer := make([]byte, bufferSize)
	n, _, err := conn.ReadFromUDP(buffer)
	if err != nil || string(buffer[:n]) != "READY" {
		fmt.Println("Error or server not ready:", err)
		return
	}

	file, err := os.Create(fileName)
	if err != nil {
		fmt.Println("Error creating file:", err)
		return
	}
	defer file.Close()

	for {
		n, _, err := conn.ReadFromUDP(buffer)
		if err != nil {
			fmt.Println("Error reading from UDP:", err)
			return
		}

		if string(buffer[:n]) == "EOF" {
			break
		}

		if _, err := file.Write(buffer[:n]); err != nil {
			fmt.Println("Error writing to file:", err)
			return
		}
	}

	fmt.Println("File downloaded:", fileName)
}

func handleList(conn *net.UDPConn) {
	_, err := conn.Write([]byte("LIST"))
	if err != nil {
		fmt.Println("Error sending list request:", err)
		return
	}

	buffer := make([]byte, bufferSize)
	n, _, err := conn.ReadFromUDP(buffer)
	if err != nil {
		fmt.Println("Error reading from UDP:", err)
		return
	}

	fmt.Println("Available files:")
	fmt.Println(string(buffer[:n]))
}
