package main

import (
	"fmt"
	"io"
	"net"
	"os"
	"path/filepath"
	"strings"
)

const (
	serverAddr = "localhost:9000"
	bufferSize = 1024
	storageDir = "./storage"
)

func main() {
	// Create storage directory if not exists
	if _, err := os.Stat(storageDir); os.IsNotExist(err) {
		os.Mkdir(storageDir, os.ModePerm)
	}

	addr, err := net.ResolveUDPAddr("udp", serverAddr)
	if err != nil {
		fmt.Println("Error resolving address:", err)
		return
	}

	conn, err := net.ListenUDP("udp", addr)
	if err != nil {
		fmt.Println("Error starting UDP server:", err)
		return
	}
	defer conn.Close()

	fmt.Println("Server started on", serverAddr)

	for {
		handleClient(conn)
	}
}

func handleClient(conn *net.UDPConn) {
	buffer := make([]byte, bufferSize)
	n, clientAddr, err := conn.ReadFromUDP(buffer)
	if err != nil {
		fmt.Println("Error reading from UDP:", err)
		return
	}

	command := strings.TrimSpace(string(buffer[:n]))
	parts := strings.Split(command, " ")
	action := parts[0]

	if action == "UPLOAD" && len(parts) == 2 {
		fileName := parts[1]
		handleUpload(conn, clientAddr, fileName)
	} else if action == "DOWNLOAD" && len(parts) == 2 {
		fileName := parts[1]
		handleDownload(conn, clientAddr, fileName)
	} else if action == "LIST" {
		handleList(conn, clientAddr)
	} else {
		fmt.Println("Invalid command:", command)
	}
}

func handleUpload(conn *net.UDPConn, clientAddr *net.UDPAddr, fileName string) {
	filePath := filepath.Join(storageDir, fileName)
	file, err := os.Create(filePath)
	if err != nil {
		fmt.Println("Error creating file:", err)
		return
	}
	defer file.Close()

	conn.WriteToUDP([]byte("READY"), clientAddr)

	for {
		buffer := make([]byte, bufferSize)
		n, _, err := conn.ReadFromUDP(buffer)
		if err != nil {
			fmt.Println("Error reading from UDP:", err)
			return
		}

		if string(buffer[:n]) == "EOF" {
			break
		}

		if _, err := file.Write(buffer[:n]); err != nil {
			fmt.Println("Error writing to file:", err)
			return
		}
	}

	fmt.Println("File uploaded:", fileName)
	conn.WriteToUDP([]byte("UPLOAD COMPLETE"), clientAddr)
}

func handleDownload(conn *net.UDPConn, clientAddr *net.UDPAddr, fileName string) {
	filePath := filepath.Join(storageDir, fileName)
	file, err := os.Open(filePath)
	if err != nil {
		fmt.Println("Error opening file:", err)
		conn.WriteToUDP([]byte("ERROR: File not found"), clientAddr)
		return
	}
	defer file.Close()

	conn.WriteToUDP([]byte("READY"), clientAddr)

	buffer := make([]byte, bufferSize)
	for {
		n, err := file.Read(buffer)
		if err != nil && err != io.EOF {
			fmt.Println("Error reading from file:", err)
			return
		}
		if n == 0 {
			break
		}

		conn.WriteToUDP(buffer[:n], clientAddr)
	}

	conn.WriteToUDP([]byte("EOF"), clientAddr)
	fmt.Println("File downloaded:", fileName)
}

func handleList(conn *net.UDPConn, clientAddr *net.UDPAddr) {
	files, err := os.ReadDir(storageDir)
	if err != nil {
		fmt.Println("Error reading storage directory:", err)
		conn.WriteToUDP([]byte("ERROR: Could not list files"), clientAddr)
		return
	}

	var fileList string
	for _, file := range files {
		fileList += file.Name() + "\n"
	}

	conn.WriteToUDP([]byte(fileList), clientAddr)
}
