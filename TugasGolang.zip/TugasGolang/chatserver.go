package main

import (
	"bufio"
	"fmt"
	"net"
	"os"
	"strings"
	"sync"
)

var clients = make(map[net.Conn]string)
var mu sync.Mutex
var chatHistory = "chat_history.txt"

func main() {
	listener, err := net.Listen("tcp", ":8080")
	if err != nil {
		fmt.Println("Error starting server:", err)
		return
	}
	defer listener.Close()

	fmt.Println("Server started on :8080")

	go readFromStdin()

	for {
		conn, err := listener.Accept()
		if err != nil {
			fmt.Println("Error accepting connection:", err)
			continue
		}

		mu.Lock()
		clients[conn] = conn.RemoteAddr().String()
		mu.Unlock()

		go handleConnection(conn)
	}
}

func handleConnection(conn net.Conn) {
	defer func() {
		mu.Lock()
		delete(clients, conn)
		mu.Unlock()
		conn.Close()
	}()

	for {
		message, err := bufio.NewReader(conn).ReadString('\n')
		if err != nil {
			fmt.Println("Client disconnected:", conn.RemoteAddr().String())
			break
		}

		message = strings.TrimSpace(message)
		if message == "" {
			continue
		}

		saveMessage("Client", conn.RemoteAddr().String(), message)
		broadcastMessage(fmt.Sprintf("%s: %s", conn.RemoteAddr().String(), message), conn)
	}
}

func broadcastMessage(message string, sender net.Conn) {
	mu.Lock()
	defer mu.Unlock()

	for conn := range clients {
		if conn != sender {
			fmt.Fprintln(conn, message)
		}
	}
	fmt.Println(message)
}

func readFromStdin() {
	scanner := bufio.NewScanner(os.Stdin)
	for scanner.Scan() {
		message := scanner.Text()
		if message == "" {
			continue
		}

		saveMessage("Server", "Server", message)
		broadcastMessage(fmt.Sprintf("Server: %s", message), nil)
	}

	if scanner.Err() != nil {
		fmt.Println("Error reading from stdin:", scanner.Err())
	}
}

func saveMessage(senderType, sender, message string) {
	mu.Lock()
	defer mu.Unlock()

	f, err := os.OpenFile(chatHistory, os.O_APPEND|os.O_CREATE|os.O_WRONLY, 0644)
	if err != nil {
		fmt.Println("Error opening chat history file:", err)
		return
	}
	defer f.Close()

	logMessage := fmt.Sprintf("%s [%s]: %s\n", senderType, sender, message)
	if _, err := f.WriteString(logMessage); err != nil {
		fmt.Println("Error writing to chat history file:", err)
	}
}
